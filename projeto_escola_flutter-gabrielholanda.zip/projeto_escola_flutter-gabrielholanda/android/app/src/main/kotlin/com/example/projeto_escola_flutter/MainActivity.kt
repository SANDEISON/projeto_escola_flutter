package com.example.projeto_escola_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
